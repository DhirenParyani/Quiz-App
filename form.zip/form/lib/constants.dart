const informationEditedTitle="Enter details to start the Quiz";
const informationUnEditedTitle="Candidate Information";
const InfoEditButtonText="Edit Information";
const InfoEditDoneButtonText="Done";
const firstNameStr="";
const jsonFilePath="assets/quiz.json";
const nextQuestionStr="Next Question";
const doneStr="End";
const firstNameError='Enter First name';
const lastNameError='Enter Last name';
const nickNameError='Enter Nickname';
const ageError='Enter Age';
const ageRangeError='Age should be greater than 0 and less than 200';



